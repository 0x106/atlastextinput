//
//  AtlasTextInput.h
//  AtlasTextInput
//
//  Created by Jordan Campbell on 8/01/18.
//  Copyright © 2018 Atlas Innovation. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for AtlasTextInput.
FOUNDATION_EXPORT double AtlasTextInputVersionNumber;

//! Project version string for AtlasTextInput.
FOUNDATION_EXPORT const unsigned char AtlasTextInputVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AtlasTextInput/PublicHeader.h>




